# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '144b75d0d45d9b203214626d508fefb5a29ed125f2521aa627930f060db8acadd5d38ce25455acff2f4cd13b6e329a00785502c24c97e7da8ee7158603ac2374'