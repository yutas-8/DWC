puts "WEBCAMP".length
