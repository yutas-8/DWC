puts "webcamp".upcase

