puts "計算をはじめます"
puts "２つの値を入力して下さい"
input1 = gets.to_i
input2 = gets.to_i
puts "計算結果を出力します"
puts "a*b=#{input1 * input2}"
puts "計算終了します"