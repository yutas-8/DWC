for i in 1..6 do
   puts i
end