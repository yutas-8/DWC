puts "Samの年齢は"+27.to_s+"です"
