total_price=99

if total_price>100
   puts "みかん購入。所持金に余りあり。"
elsif total_price==100
   puts "みかん購入。所持金0円。"
else 
   puts "みかんを購入することができません。"
end
