total=100
if total<200
   puts "合計は200未満です"
end

if total>=150
   puts "合計は150以上です"
end
